
<div class="mainpanel">

    <div class="contentpanel">

        <ol class="breadcrumb breadcrumb-quirk">
            <li><a href="#"><i class="fa fa-home mr5"></i> Home</a></li>
            <li><a href="#">Perlengkapan Jalan</a></li>
            <li class="active">Perlengkapan</li>
        </ol>

        <div class="panel">
            <div class="panel-heading">
                <h4 class="panel-title">Data Perlengkapan Jenis <b>Jenis</b></h4>
                <p>This can be used to show additional information about a row, useful for cases where you wish to convey more information about a row than there is space for in the host table.</p>
            </div>
            <div class="panel-body">
                <div class="table-responsive">
                    <table id="exRowTable" class="table table-bordered table-striped-col">
                        <thead>
                        <tr>
                            <th></th>
                            <th>Nama</th>
                            <th>Ruas Jalan</th>
                            <th>Kondisi</th>
                            <th>Lokasi</th>
                            <th>Posisi</th>
                            <th>Koordinat</th>
                            <th>Aksi</th>
                        </tr>
                        </thead>
                    </table>
                </div>
            </div>
        </div><!-- panel -->

    </div><!-- contentpanel -->
</div><!-- mainpanel -->