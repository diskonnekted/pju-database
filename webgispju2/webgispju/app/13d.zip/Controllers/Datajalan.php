<?php


namespace App\Controllers;


class Datajalan extends BaseController
{

}