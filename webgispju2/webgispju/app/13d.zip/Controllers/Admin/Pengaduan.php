<?php


namespace App\Controllers\Admin;


class Pengaduan extends AdminController
{

}