<?php


namespace App\Controllers;

use App\Models\HomeModel;
class Peta extends BaseController
{
    function index(){
        $jenis= $this->db->table("jenis_perlengkapan")->get()->getResult();
        $data['jenis']=$jenis;
        echo view('template/header', $data);
        echo view("maps");
        echo view("template/footer");
    }
    function perlengkapan($perlengkapanid = null){

        $perlengkapan=$this->db->table('perlengkapan_jalan a')->select('a.*, b.nama as jenis')->join('jenis_perlengkapan b', 'a.id_jenis=b.id', 'inner')->where('a.id_jenis', $perlengkapanid)->get()->getResult();
        foreach ($perlengkapan as $item) {
            if ($item->kondisi=='Baik'){
                $t='info';
            }else if($item->kondisi=='Rusak'){
                $t='Danger';
            }else{
                $t='hilang';
            }
            $array[]=['lat'=>$item->coordinate_lat,
                'lng'=>$item->coordinate_lng,
                'type'=>$t,
                'name'=>$item->nama,
                'id'=>$item->id,
                'kondisi'=>$item->kondisi,
                'jenis'=>$item->jenis,
                'posisi'=>$item->posisi,
                'keterangan'=>$item->keterangan,
                'gambar'=>$item->foto];
        }
        echo json_encode($array);
    }
    function geoLoc($id){

    }
    function perkap($id=null){
        if ($id==null){
            $id=1;
        }
        $jenis= $this->db->table("jenis_perlengkapan")->get()->getResult();
        $jeniss= $this->db->table("jenis_perlengkapan")->where('id', $id)->get()->getRow();
        $data['jenis']=$jenis;
        $datapeta['jenis']=$jeniss;
        //        $datapeta['perlengkapan']=$this->db->table('perlengkapan_jalan a')->select('a.*, b.nama as jenis, b.icon as markericon')->join('jenis_perlengkapan b', 'b.id=a.id_jenis')->where('a.id_jenis', $id)->get()->getRow();
//        var_dump($datapeta['perlengkapan']);
        echo view('template/header', $data);
        echo view('peta_ind', $datapeta);
        echo view('template/footer');
    }
    public function getRuas(){
        helper(['form', 'url']);

        $data = [];

        $db      = \Config\Database::connect();
        $builder = $db->table('ruas_jalan');

        $query = $builder->like('nama_ruas', $this->request->getVar('q'))
            ->select('id, nama_ruas as text')
            ->limit(10)->get();
        $data = $query->getResult();

        echo json_encode($data);
    }
    function detailperkap($id){

    }
}