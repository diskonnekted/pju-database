
<main id="main" data-aos="fade-up">
<section class="breadcrumbs">
        <div class="container">

            <div class="d-flex justify-content-between align-items-center">
                <h2>Inner Page</h2>
                <ol>
                    <li><a href="#">Home</a></li>
                    <li>Input pengaduan</li>
                </ol>
            </div>

        </div>
    </section><!-- End Breadcrumbs -->
    <!-- ======= Contact Section =======     -->
    <section id="contact" class="contact">
        <div class="container" data-aos="fade-up">

            <div class="section-title">

                <h3><span>FORMULIR PENGADUAN LAMPU PJU</span></h3>
                <p>Ut possimus qui ut temporibus culpa velit eveniet modi omnis est adipisci expedita at voluptas atque vitae autem.</p>
                <div class="alert alert-success mt-5" hidden>Pengaduan berhasil dikirim, Pengaduan anda akan segera diproses</div>
                <div class="alert alert-danger  mt-5">Terjadi kesalahan saat memproses Pengaduan anda, Silakan coba beberapa saat lagi</div>
            </div>
            <div class="row" data-aos="fade-up" data-aos-delay="100">

                <div class="col-lg-6 ">
                    <div id="map"></div>
<!--                    <iframe class="mb-4 mb-lg-0" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3956.598917974893!2d109.6710031142167!3d-7.398757074900106!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e7aa936b45a9029%3A0xe565a2351f8022d5!2sDinas%20Perhubungan%20Kabupaten%20Banjarnegara!5e0!3m2!1sid!2sid!4v1605589243787!5m2!1sid!2sid" frameborder="0" style="border:0; width: 100%; height: 384px;" allowfullscreen></iframe>-->
                </div>

                <div class="col-lg-6">
                    <form action="<?= base_url();?>/home/savepengaduan" method="post" enctype="multipart/form-data" class="php-email-form">
                        <input type="hidden" name="id_perl" id="id_perl" value="1">
                        <input type="hidden" name="lat" id="laplat">
                        <input type="hidden" name="lng" id="laplng">
                        <div class="row">
                            <div class="col form-group">
                                <label class="label-info small">Nama Lengkap</label>
                                <input type="text" name="name" class="form-control" id="name" placeholder="Nama Lengkap" data-rule="minlen:4" data-msg="Tulis Nama minimal 4 Karakter" required/>
                                <div class="validate"></div>
                            </div>
                            <div class="col form-group">
                                <label class="label-info small">Nomor Whatsapp Aktif</label>
                                <input type="text" class="form-control" name="wa" id="wa" placeholder="Nomor Whatsapp Aktif" data-rule="phone" data-msg="Tuliskan Nomor Whatsapp aktif anda"  required/>
                                <div class="validate"></div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="label-info small">Nomor Nik Anda</label>
                            <input type="text" class="form-control" name="nik" id="subject" placeholder="NIK" data-rule="minlen:16;maxlen:16" data-msg="16 Digit NIK anda" required/>
                            <div class="validate"></div>
                        </div>

                        <div class="form-group">
                            <label class="label-info small">Laporan</label>
                            <textarea class="form-control" name="laporan" rows="5" data-rule="required" required data-msg="Isikan Laporan Anda" placeholder="Contoh : Lampu PJU mati di ruas jalan raya talang depan minimarket kita sampai pasar pesayangan desa talang kecamatan talang"></textarea>
                            <div class="validate"></div>
                        </div>

                        <div class="form-group">
                            <label class="label-info small">Lampiran Foto</label>
                            <input type="file" class="form-control" name="lampiran" id="lampiran" accept="image/*" capture required />
                            <div class="validate"></div>
                        </div>
                        <div class="text-center"><button type="submit">Kirim Pengaduan</button></div>
                    </form>
                </div>

            </div>

        </div>
    </section><!-- End Contact Section -->

</main><!-- End #main -->

<!-- ======= Footer ======= -->
<footer id="footer">

    <div class="container py-4">
        <div class="copyright">
            &copy; Copyright <strong><span>BizLand</span></strong>. All Rights Reserved
        </div>
        <div class="credits">
            <!-- All the links in the footer should remain intact. -->
            <!-- You can delete the links only if you purchased the pro version. -->
            <!-- Licensing information: https://bootstrapmade.com/license/ -->
            <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/bizland-bootstrap-business-template/ -->
            Designed by <a href="https://bootstrapmade.com/">BootstrapMade</a>
        </div>
    </div>
</footer><!-- End Footer -->

<div id="preloader"></div>
<a href="#" class="back-to-top"><i class="icofont-simple-up"></i></a>

<!-- Vendor JS Files -->
<script src="<?= base_url('assets/');?>/vendor/jquery/jquery.min.js"></script>
<script src="<?= base_url('assets/');?>/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="<?= base_url('assets/');?>/vendor/jquery.easing/jquery.easing.min.js"></script>
<script src="<?= base_url('assets/');?>/vendor/php-email-form/validate.js"></script>
<script src="<?= base_url('assets/');?>/vendor/waypoints/jquery.waypoints.min.js"></script>
<script src="<?= base_url('assets/');?>/vendor/counterup/counterup.min.js"></script>
<script src="<?= base_url('assets/');?>/vendor/owl.carousel/owl.carousel.min.js"></script>
<script src="<?= base_url('assets/');?>/vendor/isotope-layout/isotope.pkgd.min.js"></script>
<script src="<?= base_url('assets/');?>/vendor/venobox/venobox.min.js"></script>
<script src="<?= base_url('assets/');?>/vendor/aos/aos.js"></script>

<!-- Template Main JS File -->
<script src="<?= base_url('assets/');?>/js/main.js"></script>
<script async="" defer="" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBq9ofC7xDgClYrfAgWbzAEW9Z_4rYKDLg&callback=initMap&libraries=geometry"></script>

<script>
    var map, infoWindow,geocoder,marker,accuracyStatus;
    var output = document.getElementById("map");
    function initMap() {
        map = new google.maps.Map(document.getElementById('map'), {
            zoom: 7,
            center: {lat: 0.3439242, lng:102.3072246}
        });

        infowindow = new google.maps.InfoWindow();

        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(function(position) {
                if(position.coords.accuracy<100){
                    accuracyStatus = '<strong style="color:green;"><span class="glyphicon glyphicon-ok"></span>Akurasi : '+position.coords.accuracy.toFixed(2)+' m (Bagus)</strong>';
                }
                else{
                    accuracyStatus = '<strong style="color:red;"><span class="glyphicon glyphicon-warning-sign"></span>Akurasi : '+position.coords.accuracy.toFixed(2)+' m (Lemah)</strong>';
                }
                var pos = {
                    lat: position.coords.latitude,
                    lng: position.coords.longitude,
                };
                geocoder = new google.maps.Geocoder();
                geocoder.geocode({'latLng': pos}, function(results, status) {
                    if (status == google.maps.GeocoderStatus.OK) {
                        map.setZoom(15);
                        map.setCenter(pos);
                        marker = new google.maps.Marker({
                            position: pos,
                            map: map,
                            animation: google.maps.Animation.BOUNCE,
                        });

                        var infowindowText = '<div class="text-center"><strong>Posisi Saat Ini</strong>'+results[3].formatted_address+
                        'Lat : ' + pos.lat.toFixed(5)+ ' |  Long : ' + pos.lng.toFixed(5)+
                        accuracyStatus+'</strong></div>';
                        infowindow.setContent(infowindowText);
                        infowindow.open(map, marker);
                        marker.addListener('click',function() {
                            infowindow.open(map,marker);
                        });
                        // output.innerHTML = results[0].formatted_address +
                        //     'Latitude : <span id="latitude">'+pos.lat+'</span>'+
                        //     'Longitude : <span id="longitude">'+pos.lng+'</span>';
                    }
                });
            }, function() {
                handleLocationError(true, infoWindow, map.getCenter());
            });
        } else {
            handleLocationError(false, infoWindow, map.getCenter());
        }
    }

    function handleLocationError(browserHasGeolocation, infoWindow, pos) {
        infoWindow.setPosition(pos);
        infoWindow.setContent(browserHasGeolocation ? '<span class="alert alert-danger">Error: The Geolocation service failed.</span>' : '<span class="alert alert-danger">Error: Your browser doesn\'t support geolocation.</span>');
        infoWindow.open(map);
    }
    var radius_circle;
    var markerLokasiLain = [];
    var lokasi = [
        {name: "Waroeng Six", lat: 0.4698576, lng: 101.3689378},
        {name: "Pondok Pesantren", lat: 0.4734302, lng: 101.3983134},
        {name: "Kolam Renang", lat: 0.4677678, lng: 101.3692093},
        {name: "Bakso Bintang Merpati", lat:0.4718068, lng: 101.3703589},
        {name: "Dalas Fried Chicken", lat:0.4700459, lng: 101.3667134},
        {name: "Garuda Jaya Motor", lat: 0.4680818, lng: 101.3674838},
        {name: "Giant", lat: 0.4648009, lng: 101.3804451},
    ];
    function getRadius(data){
        var i;
        var radius_km = Number(data.value);
        var lat = Number($("#latitude").text());
        var lng = Number($("#longitude").text());
        var pos = {
            lat: lat,
            lng: lng,
        };
        if (radius_circle) {
            radius_circle.setMap(null);
            radius_circle = null;
        }
        for (i = 0; i < markerLokasiLain.length; i++) {
            if (markerLokasiLain[i]) {
                markerLokasiLain[i].setMap(null);
                markerLokasiLain[i] = null;
            }
        }
        geocoder.geocode({'latLng': pos}, function(results, status) {
            var address_lat_lng = results[0].geometry.location;
            radius_circle = new google.maps.Circle({
                center: { lat: lat, lng:lng },
                strokeColor: '#2980b9',
                strokeOpacity: 0.8,
                strokeWeight: 2,
                fillColor: '#34495e',
                fillOpacity: 0.35,
                radius: radius_km * 1000,
                clickable: false,
                map: map,
            });

            if (radius_circle) map.fitBounds(radius_circle.getBounds());

            for (var j = 0; j < lokasi.length; j++) {
                (function (location) {
                    var marker_lat_lng = new google.maps.LatLng(location.lat, location.lng);
                    var distance_from_location = google.maps.geometry.spherical.computeDistanceBetween(address_lat_lng, marker_lat_lng);
                    var formatJarak;
                    if (distance_from_location <= radius_km * 1000) {
                        if (distance_from_location <= 1000) {
                            formatJarak = distance_from_location.toFixed(2)+" Meter";
                        }else {
                            formatJarak = (distance_from_location / 1000).toFixed(2)+" Kilometer";
                        }
                        var new_marker = new google.maps.Marker({
                            position: marker_lat_lng,
                            map: map,
                            title: location.name
                        });

                        google.maps.event.addListener(new_marker, 'click', function () {
                            if(infowindow){
                                infowindow.setMap(null);
                                infowindow = null;
                            }
                            infowindow = new google.maps.InfoWindow({
                                content: '<div style="color:red">'+location.name +'</div>' + ' Dengan Jarak ' + formatJarak + ' Dari Lokasi Utama',
                                size: new google.maps.Size(150,50),
                                pixelOffset: new google.maps.Size(0, -30),
                                position: marker_lat_lng, map: map
                            });
                        });
                        markerLokasiLain.push(new_marker);
                    }
                })(lokasi[j]);
            }
        });
    }
</script>
</body>

</html>