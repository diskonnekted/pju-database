<!-- ### $App Screen Content ### -->
<main class='main-content bgc-grey-100'>
    <div id='mainContent'>
        <div class="container-fluid">
            <h4 class="c-grey-900 mT-10 mB-30"></h4>
            <div class="row">
                <div class="col-md-12">
                    <div class="bgc-white bd bdrs-3 p-20 mB-20">
                        <h6 class="c-grey-900 mB-20">Peta Persebaran Perlengkapan Jalan Jenis : <b><?= $jenis->nama;?></b></h6>
                        <div id="google-map" style="padding-bottom: 75%;"></div>
                    </div>
                    <input type="hidden" id="idperlengkapan" value="<?=$jenis->id?>">
                </div>
            </div>
        </div>

    </div>
</main>

