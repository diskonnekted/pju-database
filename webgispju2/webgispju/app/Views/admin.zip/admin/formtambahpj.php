
<div class="mainpanel">

    <div class="contentpanel">

        <ol class="breadcrumb breadcrumb-quirk">
            <li><a href="index.html"><i class="fa fa-home mr5"></i> Home</a></li>
            <li><a href="general-forms.html">PJU</a></li>
            <li class="active">Survey PJU</li>
        </ol>

        <div class="row">
            <div class="col-sm-6">
                <div class="panel">
                    <div class="panel-heading">
                        <h4 class="panel-title">Form Survey</h4>
                        <p>Individual form controls automatically receive some global styling with <code>.form-control</code> class that are set to 100% width by default.</p>
                    </div>
                    <form action="<?= base_url('admin/pju/savesurvey')?>" method="post" enctype="multipart/form-data">
                        <div class="panel-body">

                            <h4 class="panel-title mb10">Jalan</h4>
                            <div class="form-group">
                                <select id="select2" name="tipejalan" class="form-control" style="width: 100%" data-placeholder="Jenis Jalan">
                                    <option value="">&nbsp;</option>
                                    <option value="K">Kabupaten</option>
                                    <option value="P">Propinsi</option>
                                    <option value="N">Nasional</option>
                                </select>
                            </div>
                            <h4 class="panel-title mb10">Ruas Jalan</h4>
                            <div class="form-group">
                                <select id="ruasjalan" name="ruasjalan" class="form-control" style="width: 100%" data-placeholder="Ruas Jalan">

                                </select>
                            </div>
                            <h4 class="panel-title mb10">Titik Koordinat</h4>

                            <div class="input-group mb15">
                                <span class="input-group-addon"><i class="glyphicon glyphicon-map-marker"></i></span>
                                <div class="timepicker">
                                    <input id="slat" type="text" name="lat" class="form-control" placeholder="Latitude"/>
                                    <input id="slng" type="text" name="lng" placeholder="Longitude" class="form-control"/></div>
<!--                                <button id="setTimeButton" class="btn btn-primary ml5" type="button">Gunakan lokasi saat ini</button>-->
                            </div>
                            <h4 class="panel-title mb10">Posisi</h4>

                            <div class="input-group mb15">

                                <label class="rdiobox">
                                    <input type="radio" name="posisi" value="kanan" checked>
                                    <span>Kanan</span>
                                </label>
                                <label class="rdiobox">
                                    <input type="radio" name="posisi" value="tengah">
                                    <span>Tengah</span>
                                </label>
                                <label class="rdiobox">
                                    <input type="radio" name="posisi" value="kiri">
                                    <span>Kiri</span>
                                </label>
                            </div>
                            <h4 class="panel-title mb10">Jenis Rambu</h4>
                            <div class="form-group">
                                <select id="jenisrambu" name="jenisRambau" class="form-control" style="width: 100%" data-placeholder="Catu Daya" placeholder="Catu Daya">
                                    <option value="">&nbsp;</option>
                                    <?php
                                    foreach ($jenis as $item) {
//                                        var_dump($item);
                                    ?>
                                    <option value="M"><?= $item->nama;?></option>
                                    <?php } ?>
                                </select>
                            </div>
<!--                            <h4 class="panel-title mb10">Bentuk Rambu</h4>-->
<!--                            <div class="form-group">-->
<!--                                <select id="bentukrambu" name="catudaya" class="form-control" style="width: 100%" data-placeholder="Catu Daya" placeholder="Catu Daya">-->
<!--                                    <option value="">&nbsp;</option>-->
<!--                                    <option value="M">Listrik Mandiri</option>-->
<!--                                    <option value="T">Listrik Tersuplai</option>-->
<!--                                </select>-->
<!--                            </div>-->

                            <h4 class="panel-title mb10">Gambar</h4>
                            <div class="form-group">
                                <!--                                <buttonn class="btn btn-info" data-toggle="modal" data-target="#takephoto" id="tf">Ambil Gambar</buttonn>-->
                                <input type="file" name="fotolokasi" accept="image/*" capture class="form-control">
                            </div>

                            <h4 class="panel-title mb10">Lampiran</h4>
                            <div class="form-group">
                                <!--                                <buttonn class="btn btn-info" data-toggle="modal" data-target="#takephoto" id="tf">Ambil Gambar</buttonn>-->
                                <input type="file" name="fotolokasi" accept="image/*" capture class="form-control">
                            </div>

                        </div>
                        <div class="panel-footer">
                            <button type="submit" class="btn btn-primary">Simpan</button>
                        </div>
                    </form>

                </div><!-- panel -->
            </div><!-- col-sm-6 -->

            <!-- ####################################################### -->

            <div class="col-sm-6">
                <div class="panel sticky-lg-top">
                    <div class="panel-heading">
                        <h4 class="panel-title">Width Sizing</h4>
                        <p>Set widths by wrapping inputs using column sizes.</p>
                    </div>
                    <div class="panel-body">
                        <div class="row mb20">
                            <div class="col-sm-5">
                                <input type="text" placeholder=".col-sm-5" class="form-control">
                            </div>
                            <div class="col-sm-7">
                                <input type="text" placeholder=".col-sm-7" class="form-control">
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-sm-8">
                                <input type="text" placeholder=".col-sm-8" class="form-control">
                            </div>
                            <div class="col-sm-4">
                                <input type="text" placeholder=".col-sm-4" class="form-control">
                            </div>
                        </div>
                    </div>
                </div>

            </div><!-- col-sm-6 -->
        </div><!-- row -->

    </div><!-- contentpanel -->
</div><!-- mainpanel -->
