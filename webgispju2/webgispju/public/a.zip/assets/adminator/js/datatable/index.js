$(function () {
    $('#dataTable').DataTable();
});
